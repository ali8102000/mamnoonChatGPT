# صور اختصاصات ممنون – حزمة أولية

25 صورة منفصلة بمقاس 512×512 بصيغة JPG، مرتبة حسب slug المستخدم في كتالوج المشروع.

**تنبيه:** الصور مولّدة بالذكاء الاصطناعي بأسلوب فوتوغرافي وليست صوراً توثيقية لأشخاص حقيقيين. يلزم تدقيقها بصرياً قبل اعتمادها. هذه الحزمة لم تُرفع بعد إلى GitHub ولم تُربط بعد بنسختي الويب والأندرويد.

## الملفات
- `build.jpg` — بناء
- `plaster.jpg` — لبخ جدران وسقوف
- `carpentry_form.jpg` — نجارة بيوت وقالب
- `flooring.jpg` — تطبيق أرضيات
- `chef.jpg` — طباخ / شيف
- `plumbing.jpg` — تأسيس ماء
- `electric_setup.jpg` — تأسيس كهرباء
- `electric_street.jpg` — ربط كهرباء وتصليح أسلاك الشارع
- `washer_repair.jpg` — تصليح غسالة
- `stove_repair.jpg` — تصليح طباخ
- `fridge_repair.jpg` — تصليح ثلاجة
- `ac_repair.jpg` — تصليح وتنظيف سبلت
- `cleaning.jpg` — تنظيف بيوت
- `wood_carpentry.jpg` — نجارة أخشاب منزلية
- `blacksmith.jpg` — حدادة
- `goods_transport.jpg` — نقل بضائع
- `furniture_moving.jpg` — نقل أثاث
- `cargo_handling.jpg` — تحميل وتنزيل
- `gardener.jpg` — تنسيق حدائق
- `internet_install.jpg` — نصب وصيانة الإنترنت
- `phone_repair.jpg` — صيانة الهواتف
- `electronics_repair.jpg` — صيانة الأجهزة الإلكترونية
- `computer_repair.jpg` — صيانة الحاسبات واللابتوبات
- `security_cameras.jpg` — تنصيب كامرات مراقبة
- `general.jpg` — خدمات منزلية عامة
